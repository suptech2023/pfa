package metier;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.query.Query;

import dao.HibernateUtil;
import entity.Employe;

public class EmployeManager {
	
	private Session session=HibernateUtil.getSessionFactory().openSession();;
	public EmployeManager() {
session=HibernateUtil.getSessionFactory().openSession();
	}
	
	//L'insertion d'un nouveau employé Requête Insert
	
	public String addEmploye(Employe e) {
		try {
			session.beginTransaction();
			session.persist(e);//insert into Employe
			session.getTransaction().commit();
			return "Insértion Bien Déroulée";
		} catch (Exception e2) {
			return "Insert PB :"+e2.getMessage();
		}
		
	}
	
	//La suppression d'un  employé Requête delete
	
		public void deleteEmploye(Employe e) {
			session.beginTransaction();
			session.remove(e);//delete from Employe
			session.getTransaction().commit();
			System.out.println("Suppression Bien Déroulée");
		}
		
		//La mise à jour d'un  employé Requête update
		
			public String updateEmploye(Employe e) {
				try {
					session.beginTransaction();
					session.merge(e);//update from Employe
					session.getTransaction().commit();
					return "Mise a jour Bien Déroulée";
				} catch (Exception e2) {
					return "Insert PB :"+e2.getMessage();
				}
				
			}
			
		//Afficher la liste des employés : Requête Select
			public List<Employe> allEmploye(){
				session.beginTransaction();
				return session.createQuery("from Employe",Employe.class).list();
			}
		//Afficher un employe à partir de son ID
			public Employe EmployeByMat(Employe e) {
				session.beginTransaction();
				
		Query<Employe> query=session.createQuery("from Employe where mat=:mat",Employe.class);
		query.setParameter("mat", e.getMat());
		return query.getSingleResult();
			}

}





